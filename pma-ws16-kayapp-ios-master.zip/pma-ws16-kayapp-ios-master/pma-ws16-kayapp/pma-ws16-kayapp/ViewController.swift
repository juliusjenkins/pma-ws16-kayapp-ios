//
//  ViewController.swift
//  pma-ws16-kayapp
//
//  Created by hdm on 13/12/16.
//  Copyright © 2016 hdm. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate {
    @IBOutlet weak var mapView: MKMapView!



    var locationManager: CLLocationManager!
    
    @IBAction func LocationAction(_ sender: AnyObject) {
        
        
        
        if(CLLocationManager.locationServicesEnabled()){
            
            
            locationManager = CLLocationManager()
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.requestAlwaysAuthorization()
            locationManager.startUpdatingLocation()
            
        }
        
    }
    
    
    var names : [String] = []
    var contacts: [String] = []
    
    override func viewDidLoad() {
                super.viewDidLoad()
        print("viewDidLoad")
        
        
        let url=URL(string:"http://api.androidhive.info/contacts/")
       
        
        /*
        let url = URL(string:"https://www.pegelonline.wsv.de/webservices/rest-api/v2/stations.json?includeTimeseries=true&includeCurrentMeasurement=true")
         */
 
 
        do {
            let allContactsData = try Data(contentsOf: url!)
            let allContacts = try JSONSerialization.jsonObject(with: allContactsData, options: JSONSerialization.ReadingOptions.allowFragments) as! [String : AnyObject]
            if let arrJSON = allContacts["contacts"] {
                for index in 0...arrJSON.count-1 {
                    
                    let aObject = arrJSON[index] as! [String : AnyObject]
                    
                    names.append(aObject["name"] as! String)
                    contacts.append(aObject["email"] as! String)
                }
            }
            print(names)
            print(contacts)
            
            //self.tableView.reloadData()
        }
        catch {
            
        }
        
        
        
      //getDataFromUrl()
      
}

  
    
    
    
    
    func locationManager(manager:CLLocationManager!, didUpdateLocation location: [AnyObject]!){
        
        let location = location.last as! CLLocation
        
        let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        
        
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        
        
        self.mapView.setRegion(region, animated: true)
    }
    
    

    
    func getDataFromUrl(){
        print("getting Data from URL")
        
        let urlString = "https://api.forecast.io/forecast/apiKey/37.5673776,122.048951"
        
        //let urlString = "https://www.pegelonline.wsv.de/webservices/rest-api/v2/stations.json?includeTimeseries=true&includeCurrentMeasurement=true"
        
        let url = URL(string: urlString)
        URLSession.shared.dataTask(with:url!) { (data, response, error) in
            if error != nil {
                print(error)
            } else {
                do {
                    
                    let parsedData = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:Any]
                    let currentConditions = parsedData["currently"] as! [String:Any]
                    
                    print(currentConditions)
                    
                    /*
                    for (key, value) in currentConditions {
                        print("\(key) - \(value) ")
                    }*/
                    
                    let currentTemperatureF = currentConditions["temperature"] as! Double
                    print(currentTemperatureF)
                } catch let error as NSError {
                    print(error)
                }
            }
            
            }.resume()
        
        
    }
    
    
    

}

