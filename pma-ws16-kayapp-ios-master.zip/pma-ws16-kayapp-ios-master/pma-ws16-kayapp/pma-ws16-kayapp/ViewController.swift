//
//  ViewController.swift
//  pma-ws16-kayapp
//
//  Created by hdm on 13/12/16.
//  Copyright © 2016 hdm. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate {
    @IBOutlet weak var mapView: MKMapView!



    var locationManager: CLLocationManager!
    
    @IBAction func LocationAction(_ sender: AnyObject) {
        
        
        
        if(CLLocationManager.locationServicesEnabled()){
            
            
            locationManager = CLLocationManager()
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.requestAlwaysAuthorization()
            locationManager.startUpdatingLocation()
            
        }
        
    }
    
    
    
    override func viewDidLoad() {
                super.viewDidLoad()
        print("viewDidLoad()")
        
        
        // Do any additional setup after loading the view, typically from a nib.
        
      
        
        /*
        let requestURL: NSURL = NSURL(string: "https://www.learnswiftonline.com/Samples/subway.json")!
        */
        
        
        
        let requestURL: NSURL = NSURL(string: "https://www.pegelonline.wsv.de/webservices/rest-api/v2/stations.json?includeTimeseries=true&includeCurrentMeasurement=true")!
        
        
        
        let urlRequest: NSMutableURLRequest = NSMutableURLRequest(url: requestURL as URL)
        let session = URLSession.shared
        let task = session.dataTask(with: urlRequest as URLRequest) {
            (data, response, error) -> Void in
            
            let httpResponse = response as! HTTPURLResponse
            let statusCode = httpResponse.statusCode
            
            if (statusCode == 200) {
                print("Everyone is fine, file downloaded successfully.")
                
                
                do{
                    
                    let json = try JSONSerialization.jsonObject(with: data!, options:.allowFragments) as! [String:AnyObject]
                    
                    
                    
                    //works
                    /*
                    if let stations = json["stations"] as? [[String: AnyObject]] {
                        
                        for station in stations {
                            
                            if let name = station["stationName"] as? String {
                                
                                if let year = station["buildYear"] as? String {
                                    print(name,year)
                                }
                                
                            }
                        }
                        
                    }
                    */
            
                  
 
 
                    
                }catch {
                    print("Error with Json: \(error)")
                }
                
            }
        }
        
        task.resume()
        
        
      
        print("end viewDidLoad()")
      
}

  
    
    
    
    
    func locationManager(manager:CLLocationManager!, didUpdateLocation location: [AnyObject]!){
        
        let location = location.last as! CLLocation
        
        let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        
        
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        
        
        self.mapView.setRegion(region, animated: true)
        
        
    }
    
    

    
    

}

