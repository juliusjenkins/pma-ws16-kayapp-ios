//
//  ViewController.swift
//  pma-ws16-kayapp
//
//  Created by hdm on 13/12/16.
//  Copyright © 2016 hdm. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate {
    @IBOutlet weak var mapView: MKMapView!
   
    @IBOutlet weak var Liste: UIButton!
    @IBOutlet weak var Favo: UIButton!
    @IBOutlet weak var Minus: UIButton!
    @IBOutlet weak var Location: UIButton!
    @IBOutlet weak var Plus: UIButton!

    var locationManager: CLLocationManager!
    
    @IBAction func zoomin(_ sender: AnyObject) {
        let span = MKCoordinateSpan(latitudeDelta: mapView.region.span.latitudeDelta/2, longitudeDelta: mapView.region.span.longitudeDelta/2)
        let region = MKCoordinateRegion(center: mapView.region.center, span: span)
        
        mapView.setRegion(region, animated: true)
    
    }
    
    @IBAction func zoomout(_ sender: AnyObject) {
        let span = MKCoordinateSpan(latitudeDelta: mapView.region.span.latitudeDelta*2, longitudeDelta: mapView.region.span.longitudeDelta*2)
        let region = MKCoordinateRegion(center: mapView.region.center, span: span)
        
        mapView.setRegion(region, animated: true)
    
    }
    @IBAction func LocationAction(_ sender: AnyObject) {
        
       
        
        if(CLLocationManager.locationServicesEnabled()){
            
            
            locationManager = CLLocationManager()
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.requestAlwaysAuthorization()
            locationManager.startUpdatingLocation()
            
        }
        mapView.setCenter((mapView.userLocation.location?.coordinate)!, animated: true)
    }
   
    
    override func viewDidLoad() {
                super.viewDidLoad()
        
        Liste.layer.borderWidth=2
        Liste.layer.borderColor=UIColor.black.cgColor
        Favo.layer.borderWidth=2
        Favo.layer.borderColor=UIColor.black.cgColor
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
        print("viewDidLoad() OK")
        
        
        // Do any additional setup after loading the view, typically from a nib.
        
        if let path = Bundle.main.url(forResource: "Data", withExtension: "json") {
            
            do {
                let jsonData = try Data(contentsOf: path, options: .mappedIfSafe)
                do {
                    if let jsonResult = try JSONSerialization.jsonObject(with: jsonData, options: JSONSerialization.ReadingOptions(rawValue: 0)) as? NSDictionary {
                        if let personArray = jsonResult.value(forKey: "Gauge") as? NSArray {
                            for (_, element) in personArray.enumerated() {
                                if let element = element as? NSDictionary {
                                    let uuid = element.value(forKey: "uuid") as! String
                                    let name = element.value(forKey: "name") as! String
                                    let longitude  = element.value(forKey: "longitude") as! Double
                                    
                                    let latitude  = element.value(forKey: "latitude") as! Double
                                    
                                    let currentMeasurement = element.value(forKey: "currentMeasurement") as! Double
                                    
                                    print("uui: \(uuid),  name: \(name), long: \(longitude), lat: \(latitude) current: \(currentMeasurement)")
                                    
                                    
                                    //set Marker on Map
                                    
                                    
                                    let annotation = MKPointAnnotation()
                                    
                                    annotation.coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
                                    
                                    annotation.title = name
                                    
                                    
                                    
                                    
                                    
                                    
                                    //color:
                                    /*
                                     gaue < 0 : orange
                                     gauge > 100: red
                                     else green
                                     */
                                    
                                    
                                    
                                    mapView.addAnnotation(annotation)
                                    mapView.showsUserLocation = true
                                }
                            }
                        }
                    }
                } catch let error as NSError {
                    print("Error: \(error)")
                }
            } catch let error as NSError {
                print("Error: \(error)")
            }
        }
        
      
      
}

  
   
    

       
    private func locationManager(manager:CLLocationManager!, didUpdateLocation location: [AnyObject]!){
        
        let location = location.last as! CLLocation
        
        let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        
        
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        
        
        self.mapView.setRegion(region, animated: true)
    }
    
    

    
    

}

